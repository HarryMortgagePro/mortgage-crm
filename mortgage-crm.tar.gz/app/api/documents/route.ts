import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/session';

export async function GET(request: NextRequest) {
  const session = await getSession();
  if (!session.isAuthenticated) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const { searchParams } = new URL(request.url);
  const applicationId = searchParams.get('applicationId') || '';
  const conditionGroup = searchParams.get('conditionGroup') || '';
  const received = searchParams.get('received');

  const documents = await prisma.document.findMany({
    where: {
      AND: [
        applicationId ? { applicationId } : {},
        conditionGroup ? { conditionGroup } : {},
        received !== null ? { received: received === 'true' } : {},
      ],
    },
    include: {
      application: {
        include: {
          client: true,
        },
      },
    },
    orderBy: { createdAt: 'desc' },
  });

  return NextResponse.json(documents);
}

export async function POST(request: NextRequest) {
  const session = await getSession();
  if (!session.isAuthenticated) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  try {
    const data = await request.json();
    const document = await prisma.document.create({
      data,
      include: {
        application: {
          include: {
            client: true,
          },
        },
      },
    });
    return NextResponse.json(document, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create document' }, { status: 500 });
  }
}
