-- AlterTable
ALTER TABLE "Application" ADD COLUMN "lenderName" TEXT;
