-- AlterTable
ALTER TABLE "Client" ADD COLUMN "referralSource" TEXT;
ALTER TABLE "Client" ADD COLUMN "tags" TEXT;
